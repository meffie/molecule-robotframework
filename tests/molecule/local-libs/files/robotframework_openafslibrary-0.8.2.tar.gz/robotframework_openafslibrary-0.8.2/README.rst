robotframework-openafslibrary
=============================

**robotframework-openafslibrary** is a Robot Framework test library for OpenAFS.

Documentation: `https://robotframework-openafslibrary.readthedocs.io <https://robotframework-openafslibrary.readthedocs.io/>`_
